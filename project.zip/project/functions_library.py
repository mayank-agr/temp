
# Import Packages
import matplotlib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing
from sklearn.metrics import confusion_matrix

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import cross_val_score
from sklearn.metrics import r2_score, mean_squared_error

#########################FUNCTIONS USED IN CLASSIFICATION############################################

# Plotting the confusion matrix
def plot_confusion_matrix(matrix, ax=None, title=None, ticklabels='auto'):
    sns.heatmap(matrix.T, square=True, annot=True, fmt='0.1f', cbar=False, \
                xticklabels=ticklabels, yticklabels=ticklabels, robust=True, ax=ax)
    plt.title(title)
    plt.xlabel('true spacegroup')
    plt.ylabel('predicted spacegroup');
    
# Function to assess accuracy of a classification algorithm
def test_classifier_total(labels_true, labels_predicted):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(labels_true, labels_predicted)
    length_cm = int(cm.shape[0])
    total_correct = 0
    total_incorrect = 0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if i==j:
                total_correct += cm[i][j]
            else:
                total_incorrect += cm[i][j]
    percent_accuracy = total_correct/(total_correct+total_incorrect)*100
    return percent_accuracy


# Function to plot grid search cv scores
def plot_grid_cv_scores(model,hyperparameters,param_name='KNN_Neighbours'):
    scores_sd=-1*model.cv_results_["mean_test_score"]
    
    fig,ax=plt.subplots(1,1)
    ax.plot(hyperparameters,scores_sd)
    ax.set_ylabel('-Grid CV Score')
    ax.set_xlabel(param_name)
    plt.suptitle('Grid CV Score vs '+param_name)
    plt.show()

### Functions to quantify error for our regression models
# Quantifying Error - mean of absolute deviation of errors
def std_err(model, X, y, type_=0):
    yhat = model.predict(X)
    return np.mean(np.abs(y[:,type_] - yhat[:,type_]))

#def CVscore(model, X, y, cv):
#    scores = cross_val_score(model, X, y, cv=cv)
    #print(scores.min(), scores.max())
#    return (np.mean(scores))

def r2score(model, X, y_true, type_=0):
    y_pred=model.predict(X)
    return r2_score(y_true[:,type_], y_pred[:,type_]) 
    #print(scores.min(), scores.max())
    return (np.mean(scores))

def performance_metrics(model,X,y,cv=3, type_=0): #type_0 is for del_Hf and type_1 is for bandgap 
    y1 = y#[:,type_]
    model_new=model#.fit(X,y1)
    std_error=std_err(model_new,X,y1, type_=type_)
    R2_score =r2score(model_new,X,y1, type_=type_)
    #CV_score =CVscore(model_new,X,y1,cv=cv)
    return R2_score,std_error#,CV_score